#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int acc;
	float cha, bal, cre, lim,new;
	
	printf("�п�J�b��(-1 to end):");
	scanf_s("%d", &acc);

	while(acc !=-1)
	{
		printf("�п�Jbeginning balance:");
		scanf_s("%f", &bal);

		printf("�п�Jtotal charges:");
		scanf_s("%f", &cha);

		printf("�п�Jtotal credits:");
		scanf_s("%f", &cre);

		printf("�п�Jcredit limit:");
		scanf_s("%f", &lim);

		new = bal + cha - cre;
		if (new > lim)
		{
			printf("Credit Limit Exceeded\n");
		}
		printf("�п�J�b��(-1 to end):");
		scanf_s("%d", &acc);
	}

	system("pause");
	return 0;
}