#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int i, j;

	for (i = 1; i <= 10; i++)
	{
		for (j = 1; j <= i - 1; j++)
		{
			printf(" ");
		}
		for (j = 1; j <=11-i; j++)
		{
			printf("*");
		}
		printf("\n");
	}
	system("pause");
	return 0;
}