#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int dol,day;
	float i, r;
	printf("Enter loan principal(-1 to end):");
	scanf_s("%d", &dol);

	

	while (dol != -1)
	{
		printf("Enter interest rate:");
		scanf_s("%f", &r);

		printf("Enter term of the loan in days:");
		scanf_s("%d", &day);

		i = dol * r *day / 365;

		printf("The interest charge is $%f\n", i);

		printf("�п�J�b��(-1 to end):");
		scanf_s("%d", &dol);
	}

	system("pause");
	return 0;
}