#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int h,r,c;

	printf("Enter # of hours worked (-1 to end):");
	scanf_s("%d", &h);

	while (h != -1)
	{
		printf("Enter hourly rate of the worker ($00.00):");
		scanf_s("%d", &r);

		if (h <= 40)
		{
			c = h * r;
		}
		else
		{
			c = (h - 40)*r*1.5+40*r;
		}

		printf("Salary is:$%d\n", c);

		printf("Enter # of hours worked (-1 to end):");
		scanf_s("%d", &h);
	}

	system("pause");
	return 0;
}