#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	float cw, pw,total;
	int code, h, r, hw;
	printf("Enter the code:");
	scanf_s("%d", &code);

	switch (code)
	{
	case 1:
		puts("hourly workers");

		printf("Enter of hours worked:");
		scanf_s("%d", &h);

		printf("Enter hourly rate of the worker:$");
		scanf_s("%d", &r);

		if (h <= 40)
		{
			hw = h * r;
			printf("Salary is:$%d\n", hw);
		}
		else
		{
			hw = (h - 40)*r*1.5 + 40 * r;
			printf("Salary is:$%d\n", hw);
		}
		
		break;
	case 2:
		puts("commission workers");

		printf("Enter gross weekly sales:$");
		scanf_s("%f", &cw);

		total = 250 + cw*0.057;

		printf("Salary is:$%.2f\n", total);
		break;
	case 3:
		puts("pieceworkers");

		printf("Enter the price of the item :$");
		scanf_s("%f", &pw);

		printf("Salary is:$%.2f\n", pw);
		break;
	}
	system("pause");
	return 0;
}